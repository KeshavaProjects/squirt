<?php
include_once 'dbconfig.php';
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Intern msu </title>
<link rel="stylesheet" href="css/style.css" type="text/css" />
</head>
<body>
<div id="header">
<label>InternMSU internship portal </label>
</div>
<div id="body">
	<h1>Thanks for applying will notify you 
    
    
    
    </h1>
    <a href="../index.php">click.
        |HOME</a>
</div>
<div id="footer">
<label>By <a href="#">tremendouschatikobo@gmail.com</a></label>
</div>
</body>
</html>